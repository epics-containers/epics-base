#!/bin/sh
edm -x traffic.edl &
./O.linux-x86/traffic traffic.stcmd
